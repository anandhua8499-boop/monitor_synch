import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld(
  'ambiSync',
  {
    version: '0.3.0',

    getScreenSources: () =>
      ipcRenderer.invoke(
        'get-screen-sources',
      ),
  },
)