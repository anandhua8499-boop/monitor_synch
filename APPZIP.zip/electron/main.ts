import {
  app,
  BrowserWindow,
  desktopCapturer,
  ipcMain,
} from 'electron'
import { join } from 'path'

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#0b0d10',

    webPreferences: {
      preload: join(__dirname, '../preload/preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    win.loadURL(process.env.ELECTRON_RENDERER_URL)
  } else {
    win.loadFile(
      join(__dirname, '../renderer/index.html'),
    )
  }
}

ipcMain.handle(
  'get-screen-sources',
  async () => {
    const sources =
      await desktopCapturer.getSources({
        types: ['screen'],
        thumbnailSize: {
          width: 640,
          height: 360,
        },
        fetchWindowIcons: false,
      })

    return sources.map((source) => ({
      id: source.id,
      name: source.name,
      thumbnail:
        source.thumbnail.toDataURL(),
    }))
  },
)

app.whenReady().then(() => {
  createWindow()

  app.on('activate', () => {
    if (
      BrowserWindow.getAllWindows()
        .length === 0
    ) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})