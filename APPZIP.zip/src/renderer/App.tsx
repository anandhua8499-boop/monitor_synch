
import {
  useEffect,
  useRef,
  useState,
} from 'react'

type ScreenSource = {
  id: string
  name: string
  thumbnail: string
}

type RGB = {
  r: number
  g: number
  b: number
}

type Zone = {
  id: number
  name: string
  r: number
  g: number
  b: number
}

const DEFAULT_WLED_IP = '192.168.1.3'

const ZONE_COUNT = 20

const PROCESS_FPS = 30
const WLED_FPS = 15
const UI_FPS = 10

const WLED_INTERVAL = 1000 / WLED_FPS
const UI_INTERVAL = 1000 / UI_FPS

function App() {
  // =====================================================
  // SCREEN
  // =====================================================

  const [sources, setSources] =
    useState<ScreenSource[]>([])

  const [selectedScreen, setSelectedScreen] =
    useState('')

  const [capturing, setCapturing] =
    useState(false)

  // =====================================================
  // RGB
  // =====================================================

  const [rgb, setRgb] = useState<RGB>({
    r: 0,
    g: 0,
    b: 0,
  })

  const [zones, setZones] =
    useState<Zone[]>([])

  // =====================================================
  // SETTINGS
  // =====================================================

  const [brightness, setBrightness] =
    useState(1)

  const [fps, setFps] =
    useState(PROCESS_FPS)

  const [smoothness, setSmoothness] =
    useState(0.7)

  // =====================================================
  // WLED
  // =====================================================

  const [wledIp, setWledIp] =
    useState(DEFAULT_WLED_IP)

  const [wledConnected, setWledConnected] =
    useState(false)

  const [wledSending, setWledSending] =
    useState(false)

  // =====================================================
  // ERROR
  // =====================================================

  const [error, setError] =
    useState('')

  // =====================================================
  // REFS
  // =====================================================

  const videoRef =
    useRef<HTMLVideoElement>(null)

  const canvasRef =
    useRef<HTMLCanvasElement>(null)

  const streamRef =
    useRef<MediaStream | null>(null)

  const animationRef =
    useRef<number | null>(null)

  const lastFrameRef =
    useRef(0)

  const lastWledUpdateRef =
    useRef(0)

  const lastUiUpdateRef =
    useRef(0)

  const previousZonesRef =
    useRef<Zone[]>([])

  const latestZonesRef =
    useRef<Zone[]>([])

  const wledRequestRef =
    useRef(false)

  const mountedRef =
    useRef(true)

  // =====================================================
  // LOAD SCREENS
  // =====================================================

  const loadScreens = async () => {
    try {
      setError('')

      console.log(
        'Requesting screen sources...',
      )

      const screens =
        await window.ambiSync.getScreenSources()

      console.log(
        'SCREEN SOURCES:',
        screens,
      )

      console.log(
        'SCREEN COUNT:',
        screens.length,
      )

      if (!mountedRef.current) {
        return
      }

      setSources(screens)

      if (
        screens.length > 0 &&
        !selectedScreen
      ) {
        setSelectedScreen(
          screens[0].id,
        )
      }
    } catch (err) {
      console.error(
        'Screen detection failed:',
        err,
      )

      if (mountedRef.current) {
        setError(
          'Unable to detect displays.',
        )
      }
    }
  }

  // =====================================================
  // INITIALIZE
  // =====================================================

  useEffect(() => {
    mountedRef.current = true

    loadScreens()

    return () => {
      mountedRef.current = false
      stopCapture()
    }
  }, [])

  // =====================================================
  // GET RGB
  // =====================================================

  const getRGB = (
    data: Uint8ClampedArray,
    width: number,
    height: number,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
  ): RGB => {
    let r = 0
    let g = 0
    let b = 0
    let count = 0

    const startX = Math.max(
      0,
      Math.floor(x1),
    )

    const endX = Math.min(
      width,
      Math.ceil(x2),
    )

    const startY = Math.max(
      0,
      Math.floor(y1),
    )

    const endY = Math.min(
      height,
      Math.ceil(y2),
    )

    // Sample every 2 pixels.
    // This significantly reduces CPU usage.
    for (
      let y = startY;
      y < endY;
      y += 2
    ) {
      for (
        let x = startX;
        x < endX;
        x += 2
      ) {
        const index =
          (y * width + x) * 4

        r += data[index]
        g += data[index + 1]
        b += data[index + 2]

        count++
      }
    }

    if (count === 0) {
      return {
        r: 0,
        g: 0,
        b: 0,
      }
    }

    return {
      r: Math.round(r / count),
      g: Math.round(g / count),
      b: Math.round(b / count),
    }
  }

  // =====================================================
  // SMOOTH
  // =====================================================

  const smoothColor = (
    current: RGB,
    previous: RGB,
    amount: number,
  ): RGB => {
    return {
      r: Math.round(
        previous.r +
          (current.r - previous.r) *
            amount,
      ),

      g: Math.round(
        previous.g +
          (current.g - previous.g) *
            amount,
      ),

      b: Math.round(
        previous.b +
          (current.b - previous.b) *
            amount,
      ),
    }
  }

  // =====================================================
  // SEND TO WLED
  // =====================================================

  const sendZonesToWLED = async (
  currentZones: Zone[],
) => {
  if (
    !wledIp ||
    currentZones.length === 0 ||
    wledRequestRef.current
  ) {
    return
  }

  wledRequestRef.current = true

  try {
    /*
      WLED segment layout:

      T1 T2 T3 T4 T5 T6
      L4               R1
      L3               R2
      L2               R3
      L1               R4
      B1 B2 B3 B4 B5 B6

      IMPORTANT:
      Change LED_COUNT to match your actual
      WS2812B LED strip.
    */

    const LED_COUNT = 60

    const colors = new Array(
      LED_COUNT,
    ).fill([0, 0, 0])

    // -------------------------------------------------
    // Helper
    // -------------------------------------------------

    const setLed = (
      index: number,
      zone: Zone,
    ) => {
      if (
        index < 0 ||
        index >= LED_COUNT
      ) {
        return
      }

      colors[index] = [
        zone.r,
        zone.g,
        zone.b,
      ]
    }

    // -------------------------------------------------
    // Get zones
    // -------------------------------------------------

    const top = currentZones.filter(
      (z) =>
        z.name.startsWith('T'),
    )

    const bottom =
      currentZones.filter(
        (z) =>
          z.name.startsWith('B'),
      )

    const left =
      currentZones.filter(
        (z) =>
          z.name.startsWith('L'),
      )

    const right =
      currentZones.filter(
        (z) =>
          z.name.startsWith('R'),
      )

    // -------------------------------------------------
    // Physical LED order
    //
    // Assuming:
    //
    // Start = TOP LEFT
    // →
    // TOP
    // →
    // RIGHT
    // →
    // BOTTOM
    // →
    // LEFT
    // -------------------------------------------------

    let ledIndex = 0

    // TOP
    for (
      let i = 0;
      i < top.length;
      i++
    ) {
      const zone =
        top[i]

      const ledsPerZone =
        Math.max(
          1,
          Math.floor(
            LED_COUNT /
              currentZones.length,
          ),
        )

      for (
        let j = 0;
        j < ledsPerZone;
        j++
      ) {
        setLed(
          ledIndex++,
          zone,
        )
      }
    }

    // RIGHT
    for (
      let i = 0;
      i < right.length;
      i++
    ) {
      const zone =
        right[i]

      const ledsPerZone =
        Math.max(
          1,
          Math.floor(
            LED_COUNT /
              currentZones.length,
          ),
        )

      for (
        let j = 0;
        j < ledsPerZone;
        j++
      ) {
        setLed(
          ledIndex++,
          zone,
        )
      }
    }

    // BOTTOM
    for (
      let i = bottom.length - 1;
      i >= 0;
      i--
    ) {
      const zone =
        bottom[i]

      const ledsPerZone =
        Math.max(
          1,
          Math.floor(
            LED_COUNT /
              currentZones.length,
          ),
        )

      for (
        let j = 0;
        j < ledsPerZone;
        j++
      ) {
        setLed(
          ledIndex++,
          zone,
        )
      }
    }

    // LEFT
    for (
      let i = left.length - 1;
      i >= 0;
      i--
    ) {
      const zone =
        left[i]

      const ledsPerZone =
        Math.max(
          1,
          Math.floor(
            LED_COUNT /
              currentZones.length,
          ),
        )

      for (
        let j = 0;
        j < ledsPerZone;
        j++
      ) {
        setLed(
          ledIndex++,
          zone,
        )
      }
    }

    // -------------------------------------------------
    // WLED JSON
    // -------------------------------------------------

    const response =
      await fetch(
        `http://${wledIp}/json/state`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json',
          },

          body: JSON.stringify({
            on: true,

            bri: Math.round(
              brightness * 255,
            ),

            seg: [
              {
                id: 0,

                start: 0,

                stop: LED_COUNT,

                col: colors,
              },
            ],
          }),
        },
      )

    if (!response.ok) {
      throw new Error(
        `WLED HTTP ${response.status}`,
      )
    }

    if (mountedRef.current) {
      setWledConnected(true)
    }
  } catch (error) {
    console.error(
      'WLED zone update failed:',
      error,
    )
  } finally {
    wledRequestRef.current =
      false
  }
}

  // =====================================================
  // TEST WLED
  // =====================================================

  const testWLED = async () => {
    if (!wledIp.trim()) {
      setError(
        'Enter the WLED IP address.',
      )

      return
    }

    try {
      setError('')

      console.log(
        'Testing WLED:',
        wledIp,
      )

      const response =
        await fetch(
          `http://${wledIp}/json`,
          {
            method: 'POST',

            headers: {
              'Content-Type':
                'application/json',
            },

            body: JSON.stringify({
              on: true,

              bri: 150,

              seg: [
                {
                  col: [
                    [255, 0, 0],
                  ],
                },
              ],
            }),
          },
        )

      if (!response.ok) {
        throw new Error(
          `HTTP ${response.status}`,
        )
      }

      setWledConnected(true)

      console.log(
        'WLED CONNECTED',
      )
    } catch (err) {
      console.error(
        'WLED connection failed:',
        err,
      )

      setWledConnected(false)

      setError(
        'WLED connection failed. Check IP and network.',
      )
    }
  }

  // =====================================================
  // CALCULATE ZONES
  // =====================================================

  const calculateZones = () => {
    const now =
      performance.now()

    const frameInterval =
      1000 / fps

    // ---------------------------------------------------
    // FPS LIMIT
    // ---------------------------------------------------

    if (
      now - lastFrameRef.current <
      frameInterval
    ) {
      animationRef.current =
        requestAnimationFrame(
          calculateZones,
        )

      return
    }

    lastFrameRef.current =
      now

    const video =
      videoRef.current

    const canvas =
      canvasRef.current

    if (!video || !canvas) {
      animationRef.current =
        requestAnimationFrame(
          calculateZones,
        )

      return
    }

    if (
      video.readyState <
      HTMLMediaElement.HAVE_CURRENT_DATA
    ) {
      animationRef.current =
        requestAnimationFrame(
          calculateZones,
        )

      return
    }

    // ---------------------------------------------------
    // SMALL PROCESSING CANVAS
    // ---------------------------------------------------

    const width = 120
    const height = 68

    canvas.width = width
    canvas.height = height

    const ctx =
      canvas.getContext('2d', {
        willReadFrequently: true,
      })

    if (!ctx) {
      return
    }

    ctx.drawImage(
      video,
      0,
      0,
      width,
      height,
    )

    const image =
      ctx.getImageData(
        0,
        0,
        width,
        height,
      )

    const data =
      image.data

    const newZones: Zone[] = []

    // =================================================
    // TOP 6
    // =================================================

    for (
      let i = 0;
      i < 6;
      i++
    ) {
      const x1 =
        (i / 6) * width

      const x2 =
        ((i + 1) / 6) * width

      const color =
        getRGB(
          data,
          width,
          height,
          x1,
          0,
          x2,
          height * 0.12,
        )

      newZones.push({
        id: newZones.length,
        name: `T${i + 1}`,
        ...color,
      })
    }

    // =================================================
    // RIGHT 4
    // =================================================

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const y1 =
        (i / 4) * height

      const y2 =
        ((i + 1) / 4) * height

      const color =
        getRGB(
          data,
          width,
          height,
          width * 0.88,
          y1,
          width,
          y2,
        )

      newZones.push({
        id: newZones.length,
        name: `R${i + 1}`,
        ...color,
      })
    }

    // =================================================
    // BOTTOM 6
    // =================================================

    for (
      let i = 0;
      i < 6;
      i++
    ) {
      const x1 =
        (i / 6) * width

      const x2 =
        ((i + 1) / 6) * width

      const color =
        getRGB(
          data,
          width,
          height,
          x1,
          height * 0.88,
          x2,
          height,
        )

      newZones.push({
        id: newZones.length,
        name: `B${i + 1}`,
        ...color,
      })
    }

    // =================================================
    // LEFT 4
    // =================================================

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const y1 =
        (i / 4) * height

      const y2 =
        ((i + 1) / 4) * height

      const color =
        getRGB(
          data,
          width,
          height,
          0,
          y1,
          width * 0.12,
          y2,
        )

      newZones.push({
        id: newZones.length,
        name: `L${i + 1}`,
        ...color,
      })
    }

    // =================================================
    // SMOOTH COLORS
    // =================================================

    const previousZones =
      previousZonesRef.current

    const processedZones =
      newZones.map(
        (zone, index) => {
          const previous =
            previousZones[index]

          let color: RGB

          if (previous) {
            color =
              smoothColor(
                zone,
                previous,
                smoothness,
              )
          } else {
            color = {
              r: zone.r,
              g: zone.g,
              b: zone.b,
            }
          }

          return {
            ...zone,

            r: Math.max(
              0,
              Math.min(
                255,
                Math.round(
                  color.r *
                    brightness,
                ),
              ),
            ),

            g: Math.max(
              0,
              Math.min(
                255,
                Math.round(
                  color.g *
                    brightness,
                ),
              ),
            ),

            b: Math.max(
              0,
              Math.min(
                255,
                Math.round(
                  color.b *
                    brightness,
                ),
              ),
            ),
          }
        },
      )

    previousZonesRef.current =
      processedZones

    latestZonesRef.current =
      processedZones

    // =================================================
    // UI UPDATE ONLY 10 FPS
    // =================================================

    if (
      now - lastUiUpdateRef.current >=
      UI_INTERVAL
    ) {
      lastUiUpdateRef.current =
        now

      let totalR = 0
      let totalG = 0
      let totalB = 0

      for (
        let i = 0;
        i < processedZones.length;
        i++
      ) {
        totalR +=
          processedZones[i].r

        totalG +=
          processedZones[i].g

        totalB +=
          processedZones[i].b
      }

      const count =
        processedZones.length

      if (mountedRef.current) {
        setZones(
          processedZones,
        )

        setRgb({
          r: Math.round(
            totalR / count,
          ),

          g: Math.round(
            totalG / count,
          ),

          b: Math.round(
            totalB / count,
          ),
        })
      }
    }

    // =================================================
    // WLED ONLY 15 FPS
    // =================================================

    if (
      wledConnected &&
      now -
        lastWledUpdateRef.current >=
        WLED_INTERVAL
    ) {
      lastWledUpdateRef.current =
        now

      sendZonesToWLED(
        processedZones,
      )
    }

    // =================================================
    // NEXT FRAME
    // =================================================

    animationRef.current =
      requestAnimationFrame(
        calculateZones,
      )
  }

  // =====================================================
  // START CAPTURE
  // =====================================================

  const startCapture = async () => {
    if (!selectedScreen) {
      setError(
        'Please select a display first.',
      )

      return
    }

    try {
      setError('')

      previousZonesRef.current =
        []

      latestZonesRef.current =
        []

      lastFrameRef.current =
        0

      lastWledUpdateRef.current =
        0

      lastUiUpdateRef.current =
        0

      const stream =
        await navigator.mediaDevices
          .getUserMedia({
            audio: false,

            video: {
              // @ts-expect-error Electron desktop capture
              mandatory: {
                chromeMediaSource:
                  'desktop',

                chromeMediaSourceId:
                  selectedScreen,
              },
            },
          })

      streamRef.current =
        stream

      const video =
        videoRef.current

      if (!video) {
        throw new Error(
          'Video element not found.',
        )
      }

      video.srcObject =
        stream

      await video.play()

      setCapturing(true)

      console.log(
        'CAPTURE STARTED',
      )

      animationRef.current =
        requestAnimationFrame(
          calculateZones,
        )
    } catch (err) {
      console.error(
        'CAPTURE ERROR:',
        err,
      )

      setCapturing(false)

      setError(
        'Unable to capture the selected display.',
      )
    }
  }

  // =====================================================
  // STOP CAPTURE
  // =====================================================

  function stopCapture() {
    if (
      animationRef.current !==
      null
    ) {
      cancelAnimationFrame(
        animationRef.current,
      )

      animationRef.current =
        null
    }

    if (streamRef.current) {
      streamRef.current
        .getTracks()
        .forEach(
          (track) => {
            track.stop()
          },
        )

      streamRef.current =
        null
    }

    if (videoRef.current) {
      videoRef.current.srcObject =
        null
    }

    previousZonesRef.current =
      []

    latestZonesRef.current =
      []

    setCapturing(false)

    setZones([])

    setRgb({
      r: 0,
      g: 0,
      b: 0,
    })
  }

  // =====================================================
  // ZONE COLOR
  // =====================================================

  const zoneColor = (
    zone: Zone,
  ) =>
    `rgb(${zone.r}, ${zone.g}, ${zone.b})`

  // =====================================================
  // RENDER
  // =====================================================

  return (
    <main className="app">

      {/* HEADER */}

      <header className="topbar">

        <div>
          <h1>
            AmbiSync
          </h1>

          <p>
            Screen reactive
            ambient lighting
          </p>
        </div>

        <span className="version">
          v0.5.0
        </span>

      </header>

      {/* ERROR */}

      {error && (
        <div className="error">
          {error}
        </div>
      )}

      {/* MAIN */}

      <section className="grid">

        {/* ==========================================
            PREVIEW
        ========================================== */}

        <div className="card preview-card">

          <div className="card-title">

            <span>
              Live Capture
            </span>

            <span className="status">

              <i
                className={
                  capturing
                    ? 'active'
                    : ''
                }
              />

              {capturing
                ? 'SYNCING'
                : 'READY'}

            </span>

          </div>

          <div className="screen-preview">

            <video
              ref={videoRef}
              muted
              playsInline
              className={
                capturing
                  ? 'live-video'
                  : 'hidden-video'
              }
            />

            {!capturing && (
              <div className="empty-screen">

                <span>
                  AMBISYNC
                </span>

                <small>
                  Select a display
                  and start sync
                </small>

              </div>
            )}

          </div>

          {/* RGB */}

          <div className="rgb-display">

            <div>

              <span>
                Average RGB
              </span>

              <strong>
                {rgb.r} · {rgb.g} · {rgb.b}
              </strong>

            </div>

            <div
              className="color-preview"
              style={{
                backgroundColor:
                  `rgb(
                    ${rgb.r},
                    ${rgb.g},
                    ${rgb.b}
                  )`,
              }}
            />

          </div>

        </div>

        {/* ==========================================
            CONTROLS
        ========================================== */}

        <aside className="card controls">

          <div className="card-title">
            AmbiSync Controls
          </div>

          {/* WLED */}

          <div className="setting">

            <div className="setting-header">

              <span>
                WLED
              </span>

              <strong>
                {wledConnected
                  ? 'CONNECTED'
                  : 'OFFLINE'}
              </strong>

            </div>

            <input
              type="text"
              value={wledIp}
              onChange={(event) =>
                setWledIp(
                  event.target.value,
                )
              }
              placeholder="192.168.1.105"
            />

            <button
              onClick={testWLED}
            >
              TEST WLED
            </button>

            {wledSending && (
              <small>
                Syncing...
              </small>
            )}

          </div>

          {/* DISPLAY */}

          <label>
            Monitor
          </label>

          <select
            value={selectedScreen}
            disabled={capturing}
            onChange={(event) =>
              setSelectedScreen(
                event.target.value,
              )
            }
          >

            <option value="">
              Select display
            </option>

            {sources.map(
              (source) => (
                <option
                  key={source.id}
                  value={source.id}
                >
                  {source.name}
                </option>
              ),
            )}

          </select>

          {/* START / STOP */}

          {!capturing ? (
            <button
              onClick={
                startCapture
              }
            >
              START SYNC
            </button>
          ) : (
            <button
              className="stop"
              onClick={
                stopCapture
              }
            >
              STOP SYNC
            </button>
          )}

          {/* BRIGHTNESS */}

          <div className="setting">

            <div className="setting-header">

              <span>
                Brightness
              </span>

              <strong>
                {Math.round(
                  brightness * 100,
                )}
                %
              </strong>

            </div>

            <input
              type="range"
              min="0.1"
              max="1"
              step="0.05"
              value={brightness}
              onChange={(event) =>
                setBrightness(
                  Number(
                    event.target.value,
                  ),
                )
              }
            />

          </div>

          {/* FPS */}

          <div className="setting">

            <div className="setting-header">

              <span>
                Processing FPS
              </span>

              <strong>
                {fps}
              </strong>

            </div>

            <input
              type="range"
              min="10"
              max="60"
              step="5"
              value={fps}
              onChange={(event) =>
                setFps(
                  Number(
                    event.target.value,
                  ),
                )
              }
            />

          </div>

          {/* SMOOTHNESS */}

          <div className="setting">

            <div className="setting-header">

              <span>
                Smoothing
              </span>

              <strong>
                {Math.round(
                  smoothness * 100,
                )}
                %
              </strong>

            </div>

            <input
              type="range"
              min="0.1"
              max="1"
              step="0.1"
              value={smoothness}
              onChange={(event) =>
                setSmoothness(
                  Number(
                    event.target.value,
                  ),
                )
              }
            />

          </div>

          {/* DEVICE INFO */}

          <div className="device">

            <span>
              Displays
            </span>

            <span>
              {sources.length}
            </span>

          </div>

          <div className="device">

            <span>
              RGB Zones
            </span>

            <span>
              {zones.length}
            </span>

          </div>

          <div className="device">

            <span>
              Screen Processing
            </span>

            <span>
              {fps} FPS
            </span>

          </div>

          <div className="device">

            <span>
              WLED Output
            </span>

            <span>
              {WLED_FPS} FPS
            </span>

          </div>

        </aside>

      </section>

      {/* ==========================================
          ZONE MAP
      ========================================== */}

      <section className="card zone-card">

        <div className="card-title">

          <span>
            LED Zone Preview
          </span>

          <span>
            {zones.length}/{ZONE_COUNT}
          </span>

        </div>

        <div className="monitor-map">

          {/* TOP */}

          <div className="zone-row top">

            {zones
              .filter(
                (zone) =>
                  zone.name.startsWith(
                    'T',
                  ),
              )
              .map(
                (zone) => (
                  <div
                    key={zone.id}
                    className="zone"
                    style={{
                      backgroundColor:
                        zoneColor(
                          zone,
                        ),
                    }}
                  >
                    {zone.name}
                  </div>
                ),
              )}

          </div>

          {/* MIDDLE */}

          <div className="zone-middle">

            {/* LEFT */}

            <div className="zone-column">

              {zones
                .filter(
                  (zone) =>
                    zone.name.startsWith(
                      'L',
                    ),
                )
                .map(
                  (zone) => (
                    <div
                      key={zone.id}
                      className="zone side"
                      style={{
                        backgroundColor:
                          zoneColor(
                            zone,
                          ),
                      }}
                    >
                      {zone.name}
                    </div>
                  ),
                )}

            </div>

            {/* SCREEN */}

            <div className="monitor-center">

              <span>
                SCREEN
              </span>

              <small>
                RGB SYNC
              </small>

            </div>

            {/* RIGHT */}

            <div className="zone-column">

              {zones
                .filter(
                  (zone) =>
                    zone.name.startsWith(
                      'R',
                    ),
                )
                .map(
                  (zone) => (
                    <div
                      key={zone.id}
                      className="zone side"
                      style={{
                        backgroundColor:
                          zoneColor(
                            zone,
                          ),
                      }}
                    >
                      {zone.name}
                    </div>
                  ),
                )}

            </div>

          </div>

          {/* BOTTOM */}

          <div className="zone-row bottom">

            {zones
              .filter(
                (zone) =>
                  zone.name.startsWith(
                    'B',
                  ),
              )
              .map(
                (zone) => (
                  <div
                    key={zone.id}
                    className="zone"
                    style={{
                      backgroundColor:
                        zoneColor(
                          zone,
                        ),
                    }}
                  >
                    {zone.name}
                  </div>
                ),
              )}

          </div>

        </div>

      </section>

      {/* HIDDEN PROCESSING CANVAS */}

      <canvas
        ref={canvasRef}
        style={{
          display: 'none',
        }}
      />

    </main>
  )
}

export default App
