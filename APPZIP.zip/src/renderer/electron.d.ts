export {}

declare global {
  interface Window {
    ambiSync: {
      version: string

      getScreenSources: () => Promise<
        Array<{
          id: string
          name: string
          thumbnail: string
        }>
      >
    }
  }
}