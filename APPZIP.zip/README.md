# AmbiSync v0.1.1

Electron + React + TypeScript desktop foundation for a DIY Ambilight monitor backlight.

## Run

```bash
npm install
npm run dev
```

## Current

- Electron desktop shell
- React + TypeScript UI
- AmbiSync controller UI
- Correct electron-vite main/preload/renderer structure

## Next

1. Real screen capture
2. Edge-zone RGB analysis
3. Color smoothing
4. ESP32 communication
5. WS2812B LED control
